# Jashwanthsai — Cinematic React Portfolio

A mobile-first, Reels-inspired portfolio for a technical support / customer experience professional.

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Personalization
- Add the real resume as `public/resume.pdf`.
- Replace the portrait placeholder in `src/App.tsx` with the preferred professional photo when ready.
- Replace the LinkedIn placeholder with the user's profile URL.
- Add verified project links when actual GitHub projects are available.

The portfolio intentionally avoids invented project claims and company names.
