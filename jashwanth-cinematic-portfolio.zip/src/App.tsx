import { motion, useScroll, useSpring, useTransform } from "framer-motion";
import {
  ArrowDownRight, ArrowUpRight, Mail, MapPin, Github, Linkedin,
  Network, ShieldCheck, Headphones, Database, Ticket, Sparkles,
  Terminal, Wifi, LockKeyhole
} from "lucide-react";
import { useRef } from "react";
import "./styles.css";

const skills = [
  ["Technical Troubleshooting", Headphones],
  ["Network Troubleshooting", Network],
  ["SSO / VPN / Authentication", LockKeyhole],
  ["DNS / DHCP / TCP-IP", Wifi],
  ["Salesforce / CRM", Ticket],
  ["Jira / Zendesk", Ticket],
  ["SQL & Web Basics", Database],
  ["Customer Experience", Sparkles],
];

const experience = [
  {
    label: "01",
    title: "Technical Support",
    text: "Troubleshooting customer and technical issues, identifying root causes, documenting resolutions, and driving cases toward closure.",
  },
  {
    label: "02",
    title: "Customer Support Operations",
    text: "Worked across high-volume support workflows, ticketing systems, escalations, internal tools, and customer communication channels.",
  },
  {
    label: "03",
    title: "Support Technology",
    text: "Hands-on exposure to networking fundamentals, authentication, connectivity, CRM/ticketing platforms, and structured technical investigation.",
  },
];

const capabilities = [
  ["01", "Diagnose", "Break complex issues into clear, testable steps."],
  ["02", "Communicate", "Translate technical problems into language customers understand."],
  ["03", "Resolve", "Use structured troubleshooting and escalation to move cases forward."],
  ["04", "Improve", "Spot recurring issues and turn them into better processes and knowledge."],
];

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 34 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.18 }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

function SectionMark({ number, label }: { number: string; label: string }) {
  return <div className="section-mark"><span>{number}</span><b>{label}</b></div>;
}

export default function App() {
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });
  const navScale = useTransform(progress, [0, 1], [0, 1]);

  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <main>
      <motion.div className="scroll-progress" style={{ scaleX: navScale }} />

      <nav className="nav">
        <button className="brand" onClick={() => scrollTo("home")} aria-label="Go home">
          JP<span>.</span>
        </button>
        <div className="navlinks">
          <button onClick={() => scrollTo("about")}>About</button>
          <button onClick={() => scrollTo("experience")}>Experience</button>
          <button onClick={() => scrollTo("toolkit")}>Toolkit</button>
          <button onClick={() => scrollTo("contact")}>Contact</button>
        </div>
        <a className="nav-cta" href="mailto:jashwanthsai9999@gmail.com">Let's talk <ArrowUpRight size={15}/></a>
      </nav>

      <section id="home" ref={heroRef} className="hero">
        <div className="noise" />
        <div className="hero-orb orb-left" />
        <div className="hero-orb orb-right" />
        <div className="hero-inner">
          <div className="hero-copy">
            <motion.div className="status" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
              <span className="status-dot" /> AVAILABLE FOR OPPORTUNITIES
            </motion.div>

            <motion.p className="kicker" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .15 }}>
              TECHNICAL SUPPORT · CUSTOMER EXPERIENCE · OPERATIONS
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 55 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: .9, delay: .18, ease: [0.16, 1, 0.3, 1] }}
            >
              I solve the<br />
              <span>hard stuff.</span>
            </motion.h1>

            <motion.p className="hero-lead" initial={{ opacity: 0, y: 25 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .38 }}>
              I'm Jashwanthsai — a customer-focused technical support professional
              with 2.7+ years of experience turning technical problems into clear,
              reliable outcomes.
            </motion.p>

            <motion.div className="hero-actions" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .5 }}>
              <button className="pill primary" onClick={() => scrollTo("experience")}>
                Explore my work <ArrowDownRight size={18}/>
              </button>
              <button className="pill ghost" onClick={() => scrollTo("contact")}>
                Contact me
              </button>
            </motion.div>
          </div>

          <motion.div
            className="hero-visual"
            initial={{ opacity: 0, scale: .88, rotate: 3 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1, delay: .22, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="visual-frame">
              <div className="visual-grid" />
              <div className="visual-top"><span>JP / 01</span><span>HYDERABAD · INDIA</span></div>
              <div className="visual-center">
                <div className="portrait-placeholder">
                  <div className="portrait-initials">JP</div>
                  <div className="portrait-ring ring-a" />
                  <div className="portrait-ring ring-b" />
                </div>
                <div className="floating-chip chip-a"><Terminal size={13}/> SUPPORT</div>
                <div className="floating-chip chip-b"><ShieldCheck size={13}/> TRUST</div>
                <div className="floating-chip chip-c"><Network size={13}/> CONNECT</div>
              </div>
              <div className="visual-bottom">
                <span>2.7+ YEARS</span>
                <span>TECHNICAL SUPPORT</span>
              </div>
            </div>
          </motion.div>
        </div>
        <button className="scroll-cue" onClick={() => scrollTo("about")}><span>SCROLL</span><ArrowDownRight size={15}/></button>
      </section>

      <section id="about" className="section about">
        <SectionMark number="01" label="ABOUT" />
        <div className="about-grid">
          <Reveal><h2>Technical thinking.<br/><em>Human communication.</em></h2></Reveal>
          <Reveal delay={.1}>
            <p className="statement">
              The best support experience is not just about fixing the issue.
              It's about making the customer feel that the issue is understood,
              owned, and moving toward a solution.
            </p>
            <p className="muted">
              My background combines customer-facing support with hands-on troubleshooting,
              ticket management, authentication and connectivity issues, CRM/support platforms,
              and internal tools.
            </p>
          </Reveal>
        </div>
        <div className="marquee" aria-hidden="true">
          <div>DIAGNOSE · COMMUNICATE · RESOLVE · IMPROVE · DIAGNOSE · COMMUNICATE · RESOLVE · IMPROVE ·</div>
        </div>
      </section>

      <section id="experience" className="section dark">
        <SectionMark number="02" label="EXPERIENCE" />
        <div className="experience-head">
          <Reveal><h2>Built around<br/><em>problem solving.</em></h2></Reveal>
          <Reveal delay={.1}><p className="muted big">Support is where technology, people, and process meet. That's where I do my best work.</p></Reveal>
        </div>
        <div className="experience-list">
          {experience.map((item, i) => (
            <Reveal key={item.label} delay={i * .08}>
              <article className="experience-row">
                <span className="row-number">{item.label}</span>
                <div><h3>{item.title}</h3><p>{item.text}</p></div>
                <ArrowUpRight className="row-arrow" size={22}/>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="section capabilities">
        <SectionMark number="03" label="HOW I WORK" />
        <Reveal><h2 className="huge">From <em>issue</em><br/>to outcome.</h2></Reveal>
        <div className="cap-grid">
          {capabilities.map(([n, title, text], i) => (
            <Reveal key={n} delay={i * .06}>
              <article className="cap-card">
                <span>{n}</span><h3>{title}</h3><p>{text}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="toolkit" className="section dark">
        <SectionMark number="04" label="TOOLKIT" />
        <Reveal><h2>Tools I use to <em>solve.</em></h2></Reveal>
        <div className="skills-grid">
          {skills.map(([label, Icon], i) => {
            const I = Icon as React.ElementType;
            return <Reveal key={String(label)} delay={i * .04}>
              <article className="skill-card">
                <div className="skill-icon"><I size={19}/></div>
                <span>{String(label)}</span>
                <ArrowUpRight className="skill-arrow" size={17}/>
              </article>
            </Reveal>
          })}
        </div>
      </section>

      <section id="contact" className="section contact">
        <div className="contact-glow" />
        <SectionMark number="05" label="CONTACT" />
        <Reveal>
          <p className="contact-kicker">HAVE A CHALLENGE?</p>
          <h2>Let's build the<br/><em>next solution.</em></h2>
          <p className="contact-copy">Open to technical support, customer experience, and technical operations opportunities.</p>
          <a className="email-link" href="mailto:jashwanthsai9999@gmail.com">
            <Mail size={19}/> jashwanthsai9999@gmail.com <ArrowUpRight size={18}/>
          </a>
          <div className="contact-meta">
            <span><MapPin size={15}/> Hyderabad, India</span>
            <a href="https://github.com/jashwanthsai2207" target="_blank" rel="noreferrer"><Github size={15}/> GitHub</a>
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><Linkedin size={15}/> LinkedIn</a>
          </div>
        </Reveal>
      </section>

      <footer>
        <span>© {new Date().getFullYear()} Jashwanthsai Parvataneni</span>
        <span>REACT · FRAMER MOTION · BUILT FOR THE WEB</span>
      </footer>
    </main>
  );
}
