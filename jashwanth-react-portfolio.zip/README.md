# Jashwanthsai React Portfolio

A modern dark React portfolio for a technical support / customer experience profile.

## Run locally

```bash
npm install
npm run dev
```

Then open the local Vite URL.

## Build

```bash
npm run build
```

## Personalize before publishing

1. Replace the three placeholder company names in `src/App.tsx`.
2. Replace `your.email@example.com`.
3. Add your LinkedIn and GitHub URLs.
4. Put your real `resume.pdf` inside `public/`.
5. Replace project descriptions with real projects/case studies.
6. Deploy the `dist` folder to your preferred hosting provider.

The design is intentionally recruiter-friendly while keeping a premium, contemporary visual style.
