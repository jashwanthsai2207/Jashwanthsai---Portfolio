import { motion } from "framer-motion";
import {
  ArrowUpRight, Mail, MapPin, Download, Github, Linkedin,
  Network, ShieldCheck, Headphones, Database, Ticket, Sparkles
} from "lucide-react";

const skills = [
  ["Technical Troubleshooting", Headphones],
  ["Network Fundamentals", Network],
  ["SSO & VPN", ShieldCheck],
  ["DNS / DHCP / TCP-IP", Network],
  ["Salesforce / CRM", Ticket],
  ["Jira / Zendesk", Ticket],
  ["SQL & Web Basics", Database],
  ["Customer Experience", Sparkles],
];

const experience = [
  {
    company: "Company 1",
    role: "Technical / Customer Support",
    period: "2023 — 2024",
    text: "Handled customer issues through chat and support workflows, investigated technical problems, documented resolutions, and maintained a strong customer experience."
  },
  {
    company: "Company 2",
    role: "Technical Support",
    period: "2024 — Present",
    text: "Resolved high-volume customer and technical queries, used ticketing and CRM platforms, collaborated on escalations, and followed structured troubleshooting processes."
  },
  {
    company: "Company 3",
    role: "Support Operations",
    period: "Previous experience",
    text: "Worked across support processes and internal tools, focusing on issue resolution, communication, documentation, and operational consistency."
  }
];

const projects = [
  {
    title: "Support Troubleshooting Playbook",
    tag: "Operations",
    text: "A structured troubleshooting framework covering authentication, connectivity, account access, escalation, and resolution documentation."
  },
  {
    title: "Customer Issue Knowledge Base",
    tag: "Customer Experience",
    text: "A reusable knowledge-base concept designed to turn recurring support issues into clear, searchable self-service guidance."
  },
  {
    title: "Support Analytics Dashboard",
    tag: "Data",
    text: "A portfolio concept for tracking ticket volume, resolution trends, recurring issues, and operational improvement opportunities."
  }
];

function Reveal({children, delay=0}:{children:React.ReactNode, delay?:number}) {
  return (
    <motion.div
      initial={{opacity:0, y:24}}
      whileInView={{opacity:1, y:0}}
      viewport={{once:true, amount:.15}}
      transition={{duration:.6, delay}}
    >{children}</motion.div>
  );
}

export default function App() {
  const scrollTo = (id:string) =>
    document.getElementById(id)?.scrollIntoView({behavior:"smooth"});

  return (
    <main>
      <nav className="nav">
        <button className="brand" onClick={() => scrollTo("home")}>JP<span>.</span></button>
        <div className="navlinks">
          <button onClick={() => scrollTo("about")}>About</button>
          <button onClick={() => scrollTo("experience")}>Experience</button>
          <button onClick={() => scrollTo("skills")}>Skills</button>
          <button onClick={() => scrollTo("contact")}>Contact</button>
        </div>
        <a className="nav-cta" href="/resume.pdf" download>Resume <Download size={15}/></a>
      </nav>

      <section id="home" className="hero section">
        <div className="glow glow-a"/>
        <div className="glow glow-b"/>
        <div className="hero-grid">
          <div>
            <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{duration:.7}}>
              <div className="eyebrow"><span className="pulse"/> OPEN TO OPPORTUNITIES</div>
            </motion.div>
            <motion.h1
              initial={{opacity:0,y:35}} animate={{opacity:1,y:0}}
              transition={{duration:.8,delay:.1}}
            >
              Technical support<br/>
              <em>that solves.</em>
            </motion.h1>
            <motion.p className="hero-copy"
              initial={{opacity:0,y:20}} animate={{opacity:1,y:0}}
              transition={{duration:.7,delay:.25}}
            >
              I'm Jashwanthsai — a customer-focused support professional who
              turns complex technical problems into clear, reliable solutions.
            </motion.p>
            <motion.div className="actions"
              initial={{opacity:0,y:15}} animate={{opacity:1,y:0}}
              transition={{duration:.6,delay:.4}}
            >
              <button className="primary" onClick={() => scrollTo("experience")}>
                Explore my work <ArrowUpRight size={18}/>
              </button>
              <button className="secondary" onClick={() => scrollTo("contact")}>
                Get in touch
              </button>
            </motion.div>
          </div>

          <motion.div className="hero-card"
            initial={{opacity:0,scale:.94}} animate={{opacity:1,scale:1}}
            transition={{duration:.8,delay:.2}}
          >
            <div className="card-top"><span>PROFILE</span><span>HYDERABAD, INDIA</span></div>
            <div className="orbit">
              <div className="orbit-ring ring1"/>
              <div className="orbit-ring ring2"/>
              <div className="core">JP</div>
              <span className="orb orb1">SSO</span>
              <span className="orb orb2">CRM</span>
              <span className="orb orb3">SQL</span>
              <span className="orb orb4">NET</span>
            </div>
            <div className="card-bottom">
              <strong>2.7+ years</strong>
              <span>support & customer operations</span>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="about" className="section">
        <Reveal><div className="section-label">01 / ABOUT</div></Reveal>
        <div className="two-col">
          <Reveal>
            <h2>Technical thinking.<br/><span>Human communication.</span></h2>
          </Reveal>
          <Reveal delay={.1}>
            <p className="large-copy">
              I work at the intersection of technology and customer experience.
              My approach is simple: understand the issue, isolate the cause,
              communicate clearly, and drive the problem toward resolution.
            </p>
            <p className="muted">
              My experience includes technical/customer support, troubleshooting,
              ticket management, authentication and connectivity issues, and
              working with support platforms and internal tools.
            </p>
          </Reveal>
        </div>
      </section>

      <section id="experience" className="section dark-section">
        <Reveal><div className="section-label">02 / EXPERIENCE</div></Reveal>
        <div className="timeline">
          {experience.map((item,i)=>(
            <Reveal key={item.company} delay={i*.08}>
              <article className="timeline-item">
                <div className="timeline-dot"/>
                <div className="time">{item.period}</div>
                <div>
                  <div className="role">{item.role}</div>
                  <div className="company">{item.company}</div>
                  <p>{item.text}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="skills" className="section">
        <Reveal><div className="section-label">03 / TOOLKIT</div></Reveal>
        <Reveal>
          <h2 className="section-title">Tools I use to <em>solve.</em></h2>
        </Reveal>
        <div className="skills-grid">
          {skills.map(([label, Icon],i)=>{
            const I = Icon as React.ElementType;
            return <Reveal key={String(label)} delay={i*.04}>
              <div className="skill-card">
                <I size={21}/>
                <span>{String(label)}</span>
                <ArrowUpRight className="skill-arrow" size={17}/>
              </div>
            </Reveal>
          })}
        </div>
      </section>

      <section className="section dark-section">
        <Reveal><div className="section-label">04 / SELECTED WORK</div></Reveal>
        <div className="projects">
          {projects.map((p,i)=>(
            <Reveal key={p.title} delay={i*.08}>
              <article className="project-card">
                <div className="project-number">0{i+1}</div>
                <div className="project-tag">{p.tag}</div>
                <h3>{p.title}</h3>
                <p>{p.text}</p>
                <span className="project-link">Case study concept <ArrowUpRight size={16}/></span>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="contact" className="section contact">
        <Reveal>
          <div className="section-label">05 / CONTACT</div>
          <h2>Let's solve something<br/><em>interesting.</em></h2>
          <p className="contact-copy">For technical support, customer experience, or technical operations opportunities.</p>
          <a className="email" href="mailto:your.email@example.com">
            <Mail size={20}/> your.email@example.com <ArrowUpRight size={18}/>
          </a>
          <div className="contact-meta">
            <span><MapPin size={16}/> Hyderabad, India</span>
            <span>
              <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><Linkedin size={17}/> LinkedIn</a>
            </span>
            <span>
              <a href="https://github.com/" target="_blank" rel="noreferrer"><Github size={17}/> GitHub</a>
            </span>
          </div>
        </Reveal>
      </section>

      <footer>
        <span>© {new Date().getFullYear()} Jashwanthsai Parvataneni</span>
        <span>Built with React + Motion</span>
      </footer>
    </main>
  );
}